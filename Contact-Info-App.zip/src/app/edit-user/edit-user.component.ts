import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../services/api.service';
import { User } from '../model/user.model';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  @Input() user: User;
  editUserForm: FormGroup;
  public errorMsg;

  constructor(
    private formBuilder: FormBuilder,
    private apiService: ApiService,
    private route: ActivatedRoute,
    private location: Location
  ) {

    this.editUserForm = this.formBuilder.group({
      id: [''],
      firstname: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      lastname: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      email: [
        '', Validators.compose([
          Validators.required,
          Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}$')
        ])
      ],
      phone: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
          Validators.pattern('[0-9]*')
        ])
      ],
      status: [
        '', Validators.compose([
          Validators.required
        ])
      ]

    });
   }

  ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id');
    this.apiService.getUserById(id)
    .subscribe(
      user => this.user = user
    );
  }

  onSubmit() {
    // stop here if form is invalid
    if (this.editUserForm.invalid) {
      return;
    } else {
      this.apiService.updateUser(this.editUserForm.value).subscribe(
        result => {
          this.goBack();
        },
        error => this.errorMsg = error
      );
    }
  }

  goBack(): void {
    this.location.back();
  }

}
