import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { User } from '../model/user.model';
import { ApiService } from '../services/api.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  id: number;
  addUserForm: FormGroup;
  public errorMsg;

  constructor(
    private apiService: ApiService,
    private formBuilder: FormBuilder,
    private location: Location,
    private route: ActivatedRoute
  ) {

    this.addUserForm = this.formBuilder.group({
      id: [''],
      firstname: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      lastname: [
        '', Validators.compose([
          Validators.required
        ])
      ],
      email: [
        '', Validators.compose([
          Validators.required,
          Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}$')
        ])
      ],
      phone: [
        '', Validators.compose([
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
          Validators.pattern('[0-9]*')
        ])
      ],
      status: [
        '', Validators.compose([
          Validators.required
        ])
      ]

    });
  }

  ngOnInit() {
    this.apiService.getAllUsers()
    .subscribe(
      data => {
        const max = data.reduce(function(prev, current) {
          return (prev.id > current.id) ? prev : current;
      });
      this.id = ++max.id;
       },
       error => this.errorMsg = error
    );
  }
  onSubmit() {
    // stop here if form is invalid
    if (this.addUserForm.invalid) {
      return;
    } else {
      this.addUserForm.patchValue({id: this.id});
      this.apiService.createUser(this.addUserForm.value).subscribe(
        result => {
          this.goBack();
        },
        error => this.errorMsg = error
      );
    }
  }

  goBack(): void {
    this.location.back();
  }
}
