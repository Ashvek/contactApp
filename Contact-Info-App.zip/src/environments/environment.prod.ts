export const environment = {
  production: true,

  // URL of Production API
  apiUrl: 'http://localhost:3000'
};
