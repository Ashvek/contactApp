import {User} from './user.model';

describe('Users', () => {
  it('should create an instance', () => {
    expect(new User()).toBeTruthy();
  });

  it('should accept values in the constructor', () => {
    let user = new User({
      id: 1,
      firstname : 'Ashvek',
      lastname : 'Gaonkar',
      email: 'gaonkarash@gmail.com',
      phone: 9833445577,
      active: true
    });
    expect(user.id).toEqual(1);
    expect(user.firstname).toEqual('Ashvek');
    expect(user.lastname).toEqual('Gaonkar');
    expect(user.email).toEqual('gaonkarash@gmail.com');
    expect(user.phone).toEqual(9833445577);
    expect(user.active).toEqual(true);
  });

});
