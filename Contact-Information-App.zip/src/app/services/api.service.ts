import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { User } from '../model/user.model';
import { Observable } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

const API_URL = environment.apiUrl;

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  iusers: User[] = [];
  constructor(
    private http: HttpClient
  ) { }

  //API GET: Users

  public getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(API_URL + '/users').pipe(
      catchError(this.handleError)
    );
  }

  //API POST: User
  public createUser(user: User): Observable<User> {
    return this.http
    .post<User>(API_URL + '/users', user).pipe(
      retry(2),
      catchError(this.handleError)
    );
  }

  // //API GET /users/:id
  public getUserById(userid: number): Observable<User> {
    return this.http
    .get<User>(API_URL + '/users/' + userid).pipe(
      retry(2),
      catchError(this.handleError)
    );
  }

  //API PUT /users/:id
  public updateUser(user: User): Observable<User> {
    return this.http
    .put<User>(API_URL + '/users/' + user.id, user).pipe(
      retry(2),
      catchError(this.handleError)
    );
  }

  //API DELETE /users/:id
  public deleteUser(userid: number): Observable<null> {
    return this.http
    .delete<null>(API_URL + '/users/' + userid).pipe(
      retry(2),
      catchError(this.handleError)
    );
  }

  //Error Handler
  public handleError(error: HttpErrorResponse | any) {
  console.error('ApiService::handleError', error);
  return Observable.throw(error.message || 'Server Error');
  }
}
