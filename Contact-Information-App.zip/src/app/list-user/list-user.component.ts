import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.model';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class UserListComponent implements OnInit {
  users: User[] = [];
  selectedUser: User;
  public errorMsg;
  filterText;
  
  constructor(
    private apiService: ApiService
  ) { }

  ngOnInit() {
    this.apiService.getAllUsers()
    .subscribe( data => this.users = data,
                error => this.errorMsg = error
              );
  }
  deleteUser(user: User) {
    this.apiService.deleteUser(user.id).subscribe(
      data => {
        this.users = this.users.filter(u => u !== user);
      },
      error => this.errorMsg = error
    );
  }
  onSelect(user: User): void {
    this.selectedUser = user;
  }

}